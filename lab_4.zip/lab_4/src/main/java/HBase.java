
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.client.*;
import org.apache.hadoop.hbase.util.Bytes;

/**
 * Class of the lab 4
 */
public class HBase {

    // Attribute to deal with the data
    private HTable HTable;

    /**
     * Constructor of the class
     * @param dbName
     * @throws IOException
     */
    public HBase(String dbName) throws IOException {

        Configuration configuration = HBaseConfiguration.create();
        HTable = new HTable(configuration, dbName);
    }

    /**
     * Method to add or modify a column value at a specific row of the HBase
     * @param rowID
     * @param family
     * @param column
     * @param value
     * @throws IOException
     */
    public void modify(String rowID, String family, String column, String value) throws IOException {

        Put put = new Put(Bytes.toBytes(rowID));
        put.add(Bytes.toBytes(family), Bytes.toBytes(column), Bytes.toBytes(value));
        this.HTable.put(put);
    }

    /**
     * Method to retrieve the value of the data in a column at a specific row in the HBase
     * @param rowID
     * @param family
     * @param column
     * @return value
     * @throws IOException
     */
    public String get(String rowID, String family, String column) throws IOException {

        Get get = new Get(Bytes.toBytes(rowID));
        Result result = this.HTable.get(get);
        byte[] valueOthers = result.getValue(Bytes.toBytes(family), Bytes.toBytes(column));

        return Bytes.toString(valueOthers);
    }

    /**
     * Method to end the program by releasing some allocated memory
     * @throws IOException
     */
    public void finish() throws IOException {

        this.HTable.close();
    }

    /**
     * Method to display the the content of the "info" column family at a specific row
     * @param rowID
     */
    public void displayInformationPerson(String rowID) {

        try {
            System.out.println("Information of '" + rowID + "' : ");
            System.out.println(" - age : " + this.get(rowID, "info", "age"));
            System.out.println(" - gender : " + this.get(rowID, "info", "gender"));
            System.out.println(" - town : " + this.get(rowID, "info", "town"));
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to display the content of the "friend" column family at a specific row
     * @param rowID
     */
    public void displayFriendsPerson(String rowID) {

        try {
            System.out.println("Friends of '" + rowID + "' : ");
            System.out.println(" - bff : " + this.get(rowID, "friend", "bff"));
            System.out.println(" - others : " + this.get(rowID, "friend", "others"));
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to display the content of the "bff" column at a specific row
     * @param rowID
     */
    public void displayBffPerson(String rowID) {

        try {
            System.out.println("BFF of '" + rowID + "' : " + this.get(rowID, "friend", "bff"));
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to add (modify) a friend in the value of the column 'others' at a specific row
     * @param friendToAdd
     * @param rowID
     */
    public void addFriendToPeople(String friendToAdd, String rowID) {

        try {
            String valueOthersStr = this.get(rowID, "friend", "others");

            ArrayList<String> listOthers = new ArrayList<String>(Arrays.asList(valueOthersStr.split(",")));
            listOthers.add(friendToAdd);
            String listFriends = "";
            for(String friend : listOthers)
                listFriends += friend + ",";

            this.modify(rowID, "friend", "others", listFriends);
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to remove (modify) a friend in the value of the column 'others' at a specific row
     * @param friendToRemove
     * @param rowID
     */
    public void removeFriendFromPeople(String friendToRemove, String rowID) {

        try {
            String valueOthersStr = this.get(rowID, "friend", "others");

            ArrayList<String> listOthers = new ArrayList<String>(Arrays.asList(valueOthersStr.split(",")));
            for(int i = 0; i < listOthers.size(); i++) {
                if (listOthers.get(i).equals(friendToRemove)) {
                    listOthers.remove(i);
                }
            }
            String listFriends = "";
            for(String friend : listOthers) listFriends += friend + ",";

            this.modify(rowID, "friend", "others", listFriends);
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to add a row in the HBase
     * @param rowID
     * @param age
     * @param gender
     * @param town
     * @param bff
     */
    public void addPeopleToHBase(String rowID, String age, String gender, String town, String bff) {

        try {
            this.modify(rowID, "info", "age", age);
            this.modify(rowID, "info", "gender", gender);
            this.modify(rowID, "info", "town", town);

            this.modify(rowID, "friend", "bff", bff);
            this.modify(rowID, "friend", "others", "");
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Method to delete a row in the HBase
     * @param rowID
     */
    public void deletePeopleFromHBase(String rowID) {

        try {
            byte[] row = Bytes.toBytes(rowID);
            Delete delete = new Delete(row);
            this.HTable.delete(delete);
        }
        catch(Exception ex) {
            this.errorMessage();
        }
    }

    /**
     * Some funny error message
     */
    public void errorMessage() {
        System.out.println("Oh dear, something didn't work...");
    }

    /**
     * Main method of the class
     * @param args
     * @throws IOException
     */
    public static void main(String[] args) throws IOException {

        HBase test = new HBase("jmoricet");
        boolean condition = true;
        Scanner scanOption = new Scanner(System.in);
        int option;
        Scanner scanArgument = new Scanner(System.in);
        String argument;

        while(condition) {

            System.out.println(" --- MENU OPTION SOCIAL NETWORK ---");
            System.out.println("1. display the information of a person");
            System.out.println("2. display the friend list of a person");
            System.out.println("3. display the BFF of a person");
            System.out.println("4. add a friend to a person");
            System.out.println("5. remove a friend from a person");
            System.out.println("6. add a person to the social network");
            System.out.println("7. remove a person form the social network");
            System.out.println("8. quit the menu");
            System.out.println(" --------------------------------- ");

            System.out.print("Enter your choice : ");
            option = scanOption.nextInt();

            switch(option) {

                case 1:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            test.displayInformationPerson(argument);
                            System.out.println(argument);
                            break;

                case 2:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            test.displayFriendsPerson(argument);
                            break;

                case 3:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            test.displayBffPerson(argument);
                            break;

                case 4:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            System.out.println("Enter the name of the friend to add : ");
                            String friendToAdd = scanArgument.next();
                            test.addFriendToPeople(friendToAdd, argument);
                            break;

                case 5:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            System.out.println("Enter the name of the friend to remove : ");
                            String friendToRemove = scanArgument.next();
                            test.removeFriendFromPeople(friendToRemove, argument);
                            break;

                case 6:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            System.out.println("Enter the age of the person to add : ");
                            String age = scanArgument.next();
                            System.out.println("Enter the gender of the person to add : ");
                            String gender = scanArgument.next();
                            System.out.println("Enter the town of the person to add : ");
                            String town = scanArgument.next();
                            System.out.println("Enter the name of the bff : ");
                            String bff = scanArgument.next();
                            test.addPeopleToHBase(argument, age, gender, town, bff);
                            break;

                case 7:     System.out.println("Enter the name of the person : ");
                            argument = scanArgument.next();
                            test.deletePeopleFromHBase(argument);
                            break;

                case 8:     condition = false;
                            test.finish();
                            break;

                default:    System.out.println("Seriously... Come on...");
            }
        }
    }
}
